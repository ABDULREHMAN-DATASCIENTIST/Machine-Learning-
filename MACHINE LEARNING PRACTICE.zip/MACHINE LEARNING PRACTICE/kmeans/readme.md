Codes related to the K-Means clustering algorithm
